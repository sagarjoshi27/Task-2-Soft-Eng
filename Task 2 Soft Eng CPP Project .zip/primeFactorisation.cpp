#include "../headers/primeFactorisation.h"
#include <list>
#include <math.h>

//Prime factorisation algorithm originally by Vishwas Garg, this was used from: https://www.geeksforgeeks.org/print-all-prime-factors-of-a-given-number/

std::list<unsigned long long int> primeFactorisation(unsigned long long int data)
{	
	std::list<unsigned long long int> result; //Calculates prime factors of the data and gives it to the result. 
	
	if (data != 0) //Helps to prevent an error that results in a never ending loop.
	{
		while (data % 2 == 0) //This helps to figure out if two is the prime factor of the data as it is the first prime number. 
		{
			result.push_back(2);
			data = data/2;
		}	
	}
	
	for (unsigned long long int i = 3; i <= sqrt(data); i = i+2) //Now we have the even prime factors, so only the odd prime factors are left. 
	{							                                //This helps find all the odd prime factors which is why i=3.
		while (data % i == 0)		                           //finds least prime factor i which has to be less than the square root of data given. 
		{
			result.push_back(i);
			data = data/i;
		}
	}
	
	if (data > 2) // if data is a prime number and is greater than two then it prints it. 
	{
		result.push_back(data);
	}
	
	return result;
}


